
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

    <form method="post" action="<?php echo site_url('book/findbooks'); // arahkan form submit ke kontroller 'book/findbooks ?>">
    </form>

      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Daftar Kategori</h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Kategori</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            // menampilkan data kategori
            foreach ($kategori as $kat): 

            ?>
            <tr>
              <td><?php echo $kat['kategori'];?></td>
              <td><?php echo anchor ('kategori/editKategori/'.$kat['idkategori'], 'Edit', 'Edit Kategori') ?> | 
                <?php echo anchor('kategori/delete/'.$kat['idkategori'], 'Delete', 'Hapus Kategori'); ?> </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </main>
  